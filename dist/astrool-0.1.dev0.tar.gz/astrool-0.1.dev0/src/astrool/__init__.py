"""
=========
astrool
=========

Utilities and Python wrappers for Fast Astronomers

"""

__version__ = '0.1.dev0'
